const worlds=[
 {name:"Taman Rukun Islam",icon:"🕌",desc:"Kenali lima dasar agama Islam.",questions:[
 ["Ada berapa Rukun Islam?",["3","4","5","6"],2,"Rukun Islam berjumlah lima."],
 ["Rukun Islam yang pertama adalah...",["Salat","Syahadat","Zakat","Puasa"],1,"Syahadat adalah pengakuan bahwa tiada Tuhan selain Allah dan Muhammad utusan Allah."],
 ["Umat Islam wajib salat dalam sehari semalam sebanyak...",["3 waktu","4 waktu","5 waktu","6 waktu"],2,"Salat wajib dilaksanakan lima waktu."],
 ["Puasa wajib dilakukan pada bulan...",["Syawal","Ramadan","Muharam","Rajab"],1,"Umat Islam wajib berpuasa pada bulan Ramadan."],
 ["Zakat mengajarkan kita untuk...",["Berbagi","Bermalas-malasan","Boros","Marah"],0,"Zakat membersihkan harta dan membantu orang yang membutuhkan."],
 ["Ibadah haji dilaksanakan di kota...",["Madinah","Yerusalem","Makkah","Kairo"],2,"Ibadah haji dilaksanakan di Makkah."],
 ["Salat Subuh terdiri dari ... rakaat fardu.",["2","3","4","5"],0,"Salat Subuh terdiri dari dua rakaat fardu."],
 ["Sebelum salat, kita harus...",["Makan","Berwudu","Tidur","Bermain"],1,"Wudu merupakan salah satu syarat sah salat."],
 ["Orang yang mengucapkan syahadat disebut...",["Muslim","Pedagang","Musafir","Guru"],0,"Syahadat adalah bagian pertama dari Rukun Islam."],
 ["Rukun Islam yang kelima adalah...",["Puasa","Zakat","Salat","Haji"],3,"Haji wajib bagi Muslim yang mampu."]]},
 {name:"Istana Rukun Iman",icon:"✨",desc:"Belajar enam Rukun Iman.",questions:[
 ["Ada berapa Rukun Iman?",["4","5","6","7"],2,"Rukun Iman berjumlah enam."],
 ["Iman kepada Allah adalah Rukun Iman ke...",["1","2","3","4"],0,"Rukun Iman pertama adalah iman kepada Allah."],
 ["Malaikat diciptakan Allah dari...",["Tanah","Cahaya","Api","Air"],1,"Dalam ajaran Islam, malaikat diciptakan dari cahaya."],
 ["Kitab suci yang diturunkan kepada Nabi Muhammad adalah...",["Taurat","Zabur","Injil","Al-Qur'an"],3,"Al-Qur'an diturunkan kepada Nabi Muhammad SAW."],
 ["Nabi terakhir adalah...",["Nabi Musa","Nabi Isa","Nabi Muhammad","Nabi Ibrahim"],2,"Nabi Muhammad SAW adalah nabi dan rasul terakhir."],
 ["Hari akhir juga disebut hari...",["Kiamat","Libur","Lahir","Raya"],0,"Hari akhir adalah hari berakhirnya kehidupan dunia."],
 ["Percaya kepada qada dan qadar berarti iman kepada...",["Takdir Allah","Manusia","Malaikat saja","Alam"],0,"Qada dan qadar berkaitan dengan ketetapan Allah."],
 ["Malaikat yang menyampaikan wahyu adalah...",["Mikail","Jibril","Israfil","Izrail"],1,"Malaikat Jibril bertugas menyampaikan wahyu."],
 ["Malaikat yang meniup sangkakala adalah...",["Jibril","Mikail","Israfil","Raqib"],2,"Malaikat Israfil bertugas meniup sangkakala."],
 ["Rukun Iman yang terakhir adalah iman kepada...",["Kitab","Rasul","Hari akhir","Qada dan qadar"],3,"Rukun Iman keenam adalah iman kepada qada dan qadar."]]},
 {name:"Jejak Para Nabi",icon:"📖",desc:"Kenali kisah nabi dan rasul.",questions:[
 ["Nabi pertama adalah...",["Adam AS","Nuh AS","Ibrahim AS","Musa AS"],0,"Nabi Adam AS adalah manusia dan nabi pertama."],
 ["Nabi yang membuat kapal besar atas perintah Allah adalah...",["Yusuf AS","Nuh AS","Yunus AS","Sulaiman AS"],1,"Nabi Nuh AS membuat kapal atas perintah Allah."],
 ["Nabi yang mendapat mukjizat membelah laut adalah...",["Isa AS","Ibrahim AS","Musa AS","Yahya AS"],2,"Dengan izin Allah, Nabi Musa AS membelah laut."],
 ["Nabi yang ditelan ikan besar adalah...",["Yunus AS","Hud AS","Saleh AS","Luth AS"],0,"Nabi Yunus AS berada dalam perut ikan dan berdoa kepada Allah."],
 ["Ayah Nabi Ismail AS adalah...",["Nabi Yaqub","Nabi Ibrahim","Nabi Daud","Nabi Zakaria"],1,"Nabi Ibrahim AS adalah ayah Nabi Ismail AS."],
 ["Nabi yang dapat memahami bahasa hewan adalah...",["Nabi Sulaiman","Nabi Idris","Nabi Harun","Nabi Ilyas"],0,"Allah memberi Nabi Sulaiman AS kemampuan memahami bahasa hewan."],
 ["Nabi yang terkenal sangat sabar ketika diuji sakit adalah...",["Nabi Ayyub","Nabi Yusuf","Nabi Adam","Nabi Lut"],0,"Nabi Ayyub AS dikenal karena kesabarannya."],
 ["Nabi yang diberi mukjizat menyembuhkan orang sakit dengan izin Allah adalah...",["Nabi Isa","Nabi Hud","Nabi Syuaib","Nabi Ilyasa"],0,"Nabi Isa AS mendapat beberapa mukjizat dengan izin Allah."],
 ["Nabi yang dibuang ke dalam sumur oleh saudara-saudaranya adalah...",["Nabi Yusuf","Nabi Musa","Nabi Idris","Nabi Nuh"],0,"Kisah Nabi Yusuf AS mengajarkan kesabaran dan memaafkan."],
 ["Jumlah nabi dan rasul yang wajib diketahui dalam pelajaran dasar Islam adalah...",["10","15","25","30"],2,"Dalam pelajaran dasar Islam, dikenal 25 nabi dan rasul yang wajib diketahui."]]},
 {name:"Desa Doa",icon:"🤲",desc:"Kenali doa dan zikir sehari-hari.",questions:[
 ["Sebelum makan kita membaca...",["Bismillah","Selamat pagi","Amin","Sampai jumpa"],0,"Kita dianjurkan membaca basmalah sebelum makan."],
 ["Setelah makan kita mengucapkan...",["Astaghfirullah","Alhamdulillah","Allahu Akbar","Insyaallah"],1,"Alhamdulillah berarti segala puji bagi Allah."],
 ["Ketika bertemu sesama Muslim, kita mengucapkan...",["Permisi","Sampai nanti","Assalamu'alaikum","Selamat tidur"],2,"Salam merupakan doa keselamatan."],
 ["Sebelum tidur kita dianjurkan membaca...",["Doa tidur","Doa hujan","Doa bepergian","Doa berbuka"],0,"Membaca doa sebelum tidur adalah kebiasaan baik."],
 ["Ketika bersin, kita mengucapkan...",["Alhamdulillah","Bismillah","Subhanallah","Masyaallah"],0,"Orang yang bersin dianjurkan mengucapkan Alhamdulillah."],
 ["Jika berjanji melakukan sesuatu, kita mengucapkan...",["Insyaallah","Astaghfirullah","Astagfirullahaladzim","Subhanallah"],0,"Insyaallah berarti jika Allah menghendaki."],
 ["Saat memulai belajar, kita dapat membaca...",["Basmalah","Doa tidur","Salam perpisahan","Takbir saja"],0,"Memulai kegiatan baik dengan basmalah merupakan kebiasaan terpuji."],
 ["Ketika berterima kasih kepada Allah, kita mengucapkan...",["Alhamdulillah","Innalillah","Astagfirullah","Allahu a'lam"],0,"Alhamdulillah adalah ungkapan pujian dan syukur kepada Allah."],
 ["Ketika meminta ampun kepada Allah, kita membaca...",["Astaghfirullah","Bismillah","Assalamualaikum","Allahu Akbar"],0,"Astaghfirullah berarti aku memohon ampun kepada Allah."],
 ["Saat akan bepergian, kita dianjurkan membaca...",["Doa bepergian","Doa makan","Doa tidur","Doa masuk kamar mandi"],0,"Doa bepergian berisi permohonan perlindungan kepada Allah."]]},
 {name:"Kampung Akhlak",icon:"💚",desc:"Latih adab dan perilaku terpuji.",questions:[
 ["Jika bertemu guru, sebaiknya kita...",["Menyapa sopan","Berteriak","Mengabaikan","Mengejek"],0,"Menghormati guru termasuk akhlak terpuji."],
 ["Jika teman terjatuh, kita sebaiknya...",["Menertawakan","Membantu","Meninggalkan","Mengejek"],1,"Menolong teman adalah perbuatan baik."],
 ["Ketika orang tua berbicara, kita harus...",["Membentak","Mendengarkan","Pergi begitu saja","Bermain keras"],1,"Kita harus menghormati dan mendengarkan orang tua."],
 ["Jika meminjam barang, kita harus...",["Merusaknya","Menyembunyikan","Menjaga dan mengembalikan","Memberikannya ke orang lain"],2,"Barang pinjaman harus dijaga dan dikembalikan."],
 ["Sikap saat menemukan sampah di lantai adalah...",["Membuangnya ke tempat sampah","Membiarkannya","Menendangnya","Menyembunyikannya"],0,"Menjaga kebersihan adalah perilaku terpuji."],
 ["Jika melakukan kesalahan, kita sebaiknya...",["Menyalahkan orang lain","Meminta maaf","Marah","Berbohong"],1,"Berani meminta maaf menunjukkan sikap bertanggung jawab."],
 ["Saat teman berbeda pendapat, kita harus...",["Menghina","Mendengarkan dengan baik","Memusuhi","Berteriak"],1,"Menghargai pendapat orang lain adalah akhlak mulia."],
 ["Contoh berkata jujur adalah...",["Mengakui kesalahan","Berbohong","Menipu","Menyalahkan teman"],0,"Kejujuran merupakan akhlak yang sangat dianjurkan."],
 ["Ketika mendapat bantuan, kita mengucapkan...",["Terima kasih","Pergi","Diam saja","Marah"],0,"Mengucapkan terima kasih adalah bentuk menghargai kebaikan."],
 ["Kepada tetangga, kita harus bersikap...",["Ramah dan peduli","Sombong","Tidak sopan","Acuh tak acuh"],0,"Islam mengajarkan berbuat baik kepada tetangga."]]},
 {name:"Masjid Pengetahuan",icon:"🌟",desc:"Tantangan pengetahuan Islam.",questions:[
 ["Arah kiblat umat Islam adalah menuju...",["Masjid Nabawi","Ka'bah","Masjidil Aqsa","Gunung Uhud"],1,"Umat Islam menghadap Ka'bah ketika salat."],
 ["Masjid suci tempat Ka'bah berada adalah...",["Masjidil Haram","Masjid Nabawi","Masjid Quba","Masjid Istiqlal"],0,"Ka'bah berada di dalam Masjidil Haram di Makkah."],
 ["Bulan pertama dalam kalender Hijriah adalah...",["Ramadan","Syawal","Muharam","Rajab"],2,"Muharam adalah bulan pertama kalender Hijriah."],
 ["Hari raya setelah bulan Ramadan adalah...",["Iduladha","Idulfitri","Maulid Nabi","Tahun Baru"],1,"Idulfitri dirayakan setelah Ramadan."],
 ["Orang yang mengumandangkan azan disebut...",["Imam","Khatib","Muazin","Makmum"],2,"Muazin adalah orang yang mengumandangkan azan."],
 ["Salat Jumat dilaksanakan pada hari...",["Senin","Rabu","Jumat","Minggu"],2,"Salat Jumat dilaksanakan pada hari Jumat."],
 ["Tempat ibadah umat Islam disebut...",["Gereja","Pura","Masjid","Vihara"],2,"Masjid adalah tempat ibadah umat Islam."],
 ["Al-Qur'an terdiri dari ... surah.",["100","110","114","120"],2,"Al-Qur'an terdiri dari 114 surah."],
 ["Surah pertama dalam Al-Qur'an adalah...",["Al-Ikhlas","Al-Fatihah","An-Nas","Al-Baqarah"],1,"Al-Fatihah adalah surah pembuka dalam mushaf Al-Qur'an."],
 ["Malam yang lebih baik dari seribu bulan disebut...",["Lailatul Qadar","Malam Jumat","Malam Nisfu Syaban","Malam Idulfitri"],0,"Lailatul Qadar disebut dalam Surah Al-Qadr."]]}
];

let player="Sahabat Muslim",worldIndex=0,questionIndex=0,score=0,answered=false;
let totalStars=Number(localStorage.getItem("pmc_stars")||0),totalCoins=Number(localStorage.getItem("pmc_coins")||0);
const $=id=>document.getElementById(id);
function updateStats(){$("stars").textContent=totalStars;$("coins").textContent=totalCoins}
function show(id){document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));$(id).classList.add("active");window.scrollTo(0,0)}
function renderWorlds(){
 $("worldGrid").innerHTML=worlds.map((w,i)=>{const done=localStorage.getItem("pmc_world_"+i)==="yes";return `<article class="world"><div class="emoji">${w.icon}</div><h3>${w.name}</h3><p>${w.desc}</p><button data-world="${i}">${done?"Main Lagi ↻":"Mulai Misi →"}</button></article>`}).join("");
 document.querySelectorAll("[data-world]").forEach(b=>b.addEventListener("click",()=>startWorld(Number(b.dataset.world))));
}
function startWorld(i){worldIndex=i;questionIndex=0;score=0;answered=false;show("game");renderQuestion()}
function renderQuestion(){
 const w=worlds[worldIndex],q=w.questions[questionIndex];answered=false;
 $("categoryLabel").textContent=w.name.toUpperCase();$("questionText").textContent=q[0];
 $("questionLabel").textContent=`Soal ${questionIndex+1}/10`;$("progressPct").textContent=`${(questionIndex+1)*10}%`;$("progressBar").style.width=`${(questionIndex+1)*10}%`;
 $("gameStars").textContent=score;$("mascot").textContent=questionIndex%2?"👧🏻":"🧒🏻";$("feedback").textContent="";$("feedback").className="feedback";$("nextBtn").disabled=true;
 $("answers").innerHTML=q[1].map((a,i)=>`<button class="answer" data-answer="${i}">${["A","B","C","D"][i]}. ${a}</button>`).join("");
 document.querySelectorAll("[data-answer]").forEach(b=>b.addEventListener("click",()=>chooseAnswer(Number(b.dataset.answer))));
}
function chooseAnswer(i){
 if(answered)return;answered=true;const q=worlds[worldIndex].questions[questionIndex],correct=i===q[2];
 document.querySelectorAll("[data-answer]").forEach((b,n)=>{b.disabled=true;if(n===q[2])b.classList.add("correct");else if(n===i)b.classList.add("wrong")});
 if(correct){score+=10;$("gameStars").textContent=score;$("feedback").className="feedback good";$("feedback").textContent="🎉 MasyaAllah, benar! "+q[3]}
 else{$("feedback").className="feedback bad";$("feedback").textContent="💚 Belum tepat. Jawaban yang benar: "+q[1][q[2]]+". "+q[3]}
 $("nextBtn").disabled=false;$("nextBtn").textContent=questionIndex===9?"Lihat Hasil 🏆":"Berikutnya ➜";
}
function finishWorld(){
 totalStars+=score/10;totalCoins+=score;localStorage.setItem("pmc_stars",totalStars);localStorage.setItem("pmc_coins",totalCoins);localStorage.setItem("pmc_world_"+worldIndex,"yes");updateStats();
 $("earnedStars").textContent=score/10;$("resultTitle").textContent=score>=80?"MasyaAllah, "+player+"!":"Hebat, "+player+"!";
 $("resultMessage").textContent=score===100?"Sempurna! Semua jawabanmu benar.":score>=70?"Kerja bagus! Terus semangat menuntut ilmu.":"Terima kasih sudah belajar. Yuk, coba lagi agar makin pintar!";
 show("result");
}
$("startBtn").addEventListener("click",()=>{player=$("playerName").value.trim()||"Sahabat Muslim";$("welcome").textContent=`Assalamu'alaikum, ${player}! Siap memulai misi?`;renderWorlds();show("map")});
$("howBtn").addEventListener("click",()=>show("help"));$("helpBack").addEventListener("click",()=>show("home"));
$("homeBtn").addEventListener("click",()=>show("home"));$("mapBtn").addEventListener("click",()=>{renderWorlds();show("map")});
$("nextBtn").addEventListener("click",()=>{if(!answered)return;if(questionIndex<9){questionIndex++;renderQuestion()}else finishWorld()});
$("againBtn").addEventListener("click",()=>startWorld(worldIndex));$("resultMapBtn").addEventListener("click",()=>{renderWorlds();show("map")});
updateStats();